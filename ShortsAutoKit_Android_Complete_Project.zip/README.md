# Shorts Auto Kit — Android

Package/application ID:
`com.asad.shortsautokit`

This is a native Android starter project using Kotlin + Jetpack Compose.

Current:
- Native Android UI
- Video picker
- Generated metadata screen
- YouTube connection placeholder
- Facebook intentionally disabled

Not yet complete:
- Real AI video understanding
- YouTube OAuth callback
- YouTube Data API upload
- Real thumbnail generation
- Server-side secret/token handling

Important:
The SHA-1 previously entered into Google Cloud was not verified against this project's final signing key. Do NOT assume it is valid for a release APK. Generate the signing certificate from the actual build, then register that SHA-1 with the Android OAuth client.

Build with Android Studio/Gradle:
`./gradlew assembleDebug`

The resulting APK will be under:
`app/build/outputs/apk/debug/app-debug.apk`
